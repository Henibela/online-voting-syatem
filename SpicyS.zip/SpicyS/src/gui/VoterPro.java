package gui;

import database.Voter;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class VoterPro {
    JFrame jf;
    JTextField jt;
    JLabel jl, jl2, jl3, jl4;
    JButton jb, jb2;
    public VoterPro(Voter user) {
        jf = new JFrame("Profile Page");

        // Creating text field
        jt = new JTextField("About Me");
        jt.setBounds(0,0,600, 50);
        jt.setBackground(Color.BLUE);
        jt.setForeground(Color.WHITE);

        // Setting the font size on the text field
        Font font = new Font("TIMES NEW ROMAN", Font.BOLD, 18);
        jt.setFont(font);
        jt.setHorizontalAlignment(JTextField.CENTER);

        jb = new JButton(Resize("C:\\Users\\Nas\\IdeaProjects\\SpicyS\\src\\Images\\voterpro.jpeg", 100, 100));
        jb.setBounds(50, 20, 100,100);

        jl = new JLabel("Full Name: " + user.getFullName());
        jl2 = new JLabel("Phone Number: " + user.getPhoneNumber());
        jl3 = new JLabel("Age: " + user.getAge());
        jl4 = new JLabel("Email: " + user.getEmail());

        jl.setBackground(Color.WHITE);
        jl2.setBackground(Color.WHITE);
        jl3.setBackground(Color.WHITE);
        jl4.setBackground(Color.WHITE);

        jl.setForeground(Color.BLUE);
        jl2.setForeground(Color.BLUE);
        jl3.setForeground(Color.BLUE);
        jl4.setForeground(Color.BLUE);

        Font x = new Font("TIMES NEW ROMAN", Font.PLAIN, 16);
        jl.setFont(x);
        Font y = new Font("TIMES NEW ROMAN", Font.PLAIN, 16);
        jl2.setFont(y);
        Font z = new Font("TIMES NEW ROMAN", Font.PLAIN, 16);
        jl3.setFont(z);
        Font w = new Font("TIMES NEW ROMAN", Font.PLAIN, 16);
        jl4.setFont(w);

        jl.setBounds(100, 50, 400, 25);
        jl2.setBounds(100, 100, 400, 25);
        jl3.setBounds(100, 150, 400, 25);
        jl4.setBounds(100, 200, 400, 25);

        // Adding components to the frame
        jf.add(jl);
        jf.add(jl3);
        jf.add(jl4);
        jf.add(jl2);
        jf.add(jt);

        jf.setSize(600,600);
        jf.setLayout(null);
        jf.setVisible(true);
    }
    public ImageIcon Resize(String imagePath, int width, int height) {
        try {
            // Load the original image
            BufferedImage originalImage = ImageIO.read(new File(imagePath));

            // Resize the image while maintaining its aspect ratio
            Image resizedImage = originalImage.getScaledInstance(width, height, Image.SCALE_SMOOTH);

            // Create a button with the resized image
            return new ImageIcon(resizedImage);

        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }
    public static void main(String args[]){
    }
}
