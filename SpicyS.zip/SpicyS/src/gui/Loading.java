package gui;

import javax.swing.*;
import java.awt.*;


public class Loading {
    JFrame fr;
    JTextField jt;
    JProgressBar pb;
    javax.swing.Timer timer;

    Loading () {
        // Creating a frame
        fr = new JFrame("Loading Page");

        pb = new JProgressBar();
        pb.setBackground(Color.BLUE);
        pb.setBounds(200, 200, 100,  25);

        int[] value = { 0 };
        timer = new Timer(50, e -> {
            pb.setValue(value[0]++);
            if (value[0] > 100) {
                timer.stop();
                fr.dispose();
                new Main();
            }
        });
        timer.start();

        // Creating text field
        jt = new JTextField("Grand Welcome to you Nasir!!!");
        jt.setBounds(0,0,600, 50);
        jt.setBackground(Color.BLUE);
        jt.setForeground(Color.WHITE);
        jt.setEditable(false);

        fr.add(pb);
        fr.add(jt);

        // Setting the font size on the text field
        Font font = new Font("TIMES NEW ROMAN", Font.BOLD, 20);
        jt.setFont(font);
        jt.setHorizontalAlignment(JTextField.CENTER);

        fr.setSize(600, 400);
        fr.setLayout(null);
        fr.setVisible(true);

    }
    public static void main (String [] args) {
        new Loading();
    }
}
