package gui;

import database.Voter;
import database.Linker;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

public class AdminVot extends JFrame {
    private DefaultTableModel tableModel;
    private JTable voterTable;

    public AdminVot() {
        super("Voter Information Table");

        // Set up the GUI
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);

        // Create table model with column names
        tableModel = new DefaultTableModel();
        tableModel.addColumn("Full Name");
        tableModel.addColumn("Age");
        tableModel.addColumn("Phone Number");
        tableModel.addColumn("Email");
        tableModel.addColumn("Vote Status");
        tableModel.addColumn("Account Status");
        tableModel.addColumn("ID");
        tableModel.addColumn("Remove"); // New column for Remove button

        // Create JTable with the table model
        voterTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(voterTable);

        // Set button renderers and editors for the new columns
        voterTable.getColumnModel().getColumn(7).setCellRenderer(new ButtonRenderer());
        voterTable.getColumnModel().getColumn(7).setCellEditor(new ButtonEditor(new ButtonClickListener()));

        // Add components to the frame
        add(scrollPane);

        // Load voter information from the database
        loadVoterInfo();

        // Display the frame
        setVisible(true);
    }

    private void loadVoterInfo() {
        // Retrieve voter information from the Linker class
        // Assuming Linker.getVoters() returns a List<Voter> with the required information
        for (Voter voter : Linker.getVoters()) {
            tableModel.addRow(new Object[]{
                    voter.getFullName(),
                    voter.getAge(),
                    voter.getPhoneNumber(),
                    voter.getEmail(),
                    voter.getVoteStatus(),
                    voter.getAccountStatus(),
                    voter.getRandomId(),  // Corrected position for the "ID" column
                    "Remove"
            });
        }
    }

    private class ButtonClickListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            // Handle button clicks here
            if ("Remove".equals(e.getActionCommand())) {
                int selectedRow = voterTable.getSelectedRow();
                if (selectedRow != -1) {
                    // Perform removal action
                    String voterID = (String) tableModel.getValueAt(selectedRow, 6); // Assuming ID is at column index 6
                    try {
                        Linker.removeVoterByID(voterID);
                        tableModel.removeRow(selectedRow);
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                        // Handle the exception appropriately (show a message, log it, etc.)
                    }
                }
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new AdminVot());
    }
}