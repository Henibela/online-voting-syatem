package gui;

import database.Linker;
import database.Voter;
import java.io.*;
import java.awt.*;
import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.imageio.ImageIO;

public class AdminDash {
        JFrame jf;
        JLabel jl, jl2, jl3, jl4, jl5;
        JButton jb, jb2, jb3, jb4, jb5;

        public AdminDash () {
            jf = new JFrame("Admin Dashboard");

            // Creating labels
            jl = new JLabel("Voters");
            jl.setBounds(50, 150, 50, 25);
            jl2 = new JLabel("Candidates");
            jl2.setBounds(200, 150, 100, 25);
            jl3 = new JLabel("Results");
            jl3.setBounds(350, 150, 50, 25);
            jl4 = new JLabel("Notify");
            jl4.setBounds(500, 150, 50, 25);
            jl5 = new JLabel("Timer");
            jl5.setBounds(650, 150, 50, 25);

            // Adding the button icons
            jb = new JButton(Resize("C:\\Users\\Nas\\IdeaProjects\\SpicyS\\src\\Images\\profile.jpg", 100, 100));
            jb.setBounds(50, 50, 100,100);
            jb2 = new JButton(Resize("C:\\Users\\Nas\\IdeaProjects\\SpicyS\\src\\Images\\candidates.jpeg",100, 100));
            jb2.setBounds(160, 50, 100,100);
            jb3 = new JButton(Resize("C:\\Users\\Nas\\IdeaProjects\\SpicyS\\src\\Images\\results.jpeg",100, 100));
            jb3.setBounds(270, 50, 100,100);
            jb4 = new JButton(Resize("C:\\Users\\Nas\\IdeaProjects\\SpicyS\\src\\Images\\vote.jpeg",100, 100));
            jb4.setBounds(380, 50, 100,100);
            jb5 = new JButton(Resize("C:\\Users\\Nas\\IdeaProjects\\SpicyS\\src\\Images\\vote.jpeg",100, 100));
            jb5.setBounds(490, 50, 100,100);

            // Setting the bounds for the icons
            jb.setBounds(50, 80, 100, 100);
            jb2.setBounds(200, 80, 100, 100);
            jb3.setBounds(350, 80, 100, 100);
            jb4.setBounds(500, 80, 100, 100);
            jb5.setBounds(650, 80, 100, 100);

            // Setting events
            jb.addActionListener(e -> {
                new AdminVot();
                jf.dispose();
            });
            jb2.addActionListener(e -> {
                new AdminCan();
                jf.dispose();
            });
            jb3.addActionListener(e -> {
            });
            jb4.addActionListener(e -> {
            });
            jb5.addActionListener(e -> {
            });

            jf.add(jl);
            jf.add(jl2);
            jf.add(jl3);
            jf.add(jl4);
            jf.add(jb);
            jf.add(jb2);
            jf.add(jb3);
            jf.add(jb4);
            jf.add(jb5);
            jf.add(jl5);

            // Finalizing input
            jf.setSize(700, 400);
            jf.setLayout(null);
            jf.setVisible(true);
        }
        // Method for resizing images
        public ImageIcon Resize(String imagePath, int width, int height) {
            try {
                // Load the original image
                BufferedImage originalImage = ImageIO.read(new File(imagePath));

                // Resize the image while maintaining its aspect ratio
                Image resizedImage = originalImage.getScaledInstance(width, height, Image.SCALE_SMOOTH);

                // Create a button with the resized image
                return new ImageIcon(resizedImage);

            } catch (IOException e) {
                e.printStackTrace();
            }

            return null;
        }
        public static void main (String [] args) {
        }
}
