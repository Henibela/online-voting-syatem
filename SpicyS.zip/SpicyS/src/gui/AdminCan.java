package gui;

import database.Candidate;
import database.Linker;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

public class AdminCan extends JFrame {
    private DefaultTableModel tableModel;
    private JTable candidateTable;

    public AdminCan() {
        super("Candidate Information Table");

        // Set up the GUI
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);

        // Create table model with column names
        tableModel = new DefaultTableModel();
        tableModel.addColumn("Full Name");
        tableModel.addColumn("Age");
        tableModel.addColumn("Phone Number");
        tableModel.addColumn("Email");
        tableModel.addColumn("Account Status");
        tableModel.addColumn("ID");
        tableModel.addColumn("Remove"); // New column for Remove button

        // Create JTable with the table model
        candidateTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(candidateTable);

        // Set button renderers and editors for the new columns
        candidateTable.getColumnModel().getColumn(6).setCellRenderer(new ButtonRenderer());
        candidateTable.getColumnModel().getColumn(6).setCellEditor(new ButtonEditor(new ButtonClickListener()));

        // Add components to the frame
        add(scrollPane);

        // Load candidate information from the database
        loadCandidateInfo();

        // Display the frame
        setVisible(true);
    }

    private void loadCandidateInfo() {
        // Retrieve candidate information from the Linker class
        // Assuming Linker.getZCandidates() returns a List<Candidate> with the required information
        for (Candidate candidate : Linker.getZCandidates()) {
            tableModel.addRow(new Object[]{
                    candidate.getFullName(),
                    candidate.getAge(),
                    candidate.getPhoneNumber(),
                    candidate.getEmail(),
                    candidate.getAccountStatus(),
                    candidate.getRandomId(),
                    "Remove"
            });
        }
    }

    private class ButtonClickListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            // Handle button clicks here
            if ("Remove".equals(e.getActionCommand())) {
                int selectedRow = candidateTable.getSelectedRow();
                if (selectedRow != -1) {
                    // Perform removal action
                    String candidateID = (String) tableModel.getValueAt(selectedRow, 5); // Assuming ID is at column index 5
                    try {
                        Linker.removeCandidateByID(candidateID);
                        tableModel.removeRow(selectedRow);
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                        // Handle the exception appropriately (show a message, log it, etc.)
                    }
                }
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new AdminCan());
    }
}