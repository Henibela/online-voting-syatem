package gui;

import database.Linker;

import javax.swing.*;
import java.awt.*;
import java.util.Random;

public class SignUpV {
    JFrame jf;
    JTextField jt, jt2, jt3, jt4, jt5, jt6, jt7;
    JLabel jl, jl2, jl3, jl4, jl5, jl6, ja;
    JButton jb;

    public SignUpV() {
        jf = new JFrame("SignUp Page");

        // Creating text field
        jt = new JTextField("Welcome to Cbits!!!");
        jt.setBounds(0, 0, 600, 50);
        jt.setBackground(Color.WHITE);
        jt.setForeground(Color.BLUE);
        jt.setEditable(false);

        // Setting the font size of the text field
        Font font = new Font("TIMES NEW ROMAN", Font.BOLD, 20);
        jt.setFont(font);
        jt.setHorizontalAlignment(JTextField.CENTER);

        // Creating the opening text area
        ja = new JLabel("Please enter your credentials below");
        ja.setBounds(50, 65, 300, 25);

        // Setting the font of the text area
        Font xy = new Font("TIMES NEW ROMAN", Font.BOLD, 16);
        ja.setFont(xy);

        // Creating the name and password text fields
        jt2 = new JTextField("Enter Full Name");
        jt2.setBounds(350, 100, 150, 25);
        jt2.setForeground(Color.GRAY);
        jt3 = new JTextField("Enter Phone Number");
        jt3.setBounds(350, 150, 150, 25);
        jt3.setForeground(Color.GRAY);
        jt4 = new JTextField("Enter Age");
        jt4.setBounds(350, 200, 150, 25);
        jt4.setForeground(Color.GRAY);
        jt5 = new JTextField("Enter Email");
        jt5.setBounds(350, 250, 150, 25);
        jt5.setForeground(Color.GRAY);
        jt6 = new JTextField("Enter Password");
        jt6.setBounds(350, 300, 150, 25);
        jt6.setForeground(Color.GRAY);
        jt7 = new JTextField("Confirm Password");
        jt7.setBounds(350, 350, 150, 25);
        jt7.setForeground(Color.GRAY);

        // Creating the name and password labels
        jl = new JLabel("Full Name");
        jl.setBounds(100, 100, 100, 25);
        jl.setForeground(Color.BLUE);
        jl2 = new JLabel("Phone Number");
        jl2.setBounds(100, 150, 100, 25);
        jl2.setForeground(Color.BLUE);
        jl3 = new JLabel("Age");
        jl3.setBounds(100, 200, 100, 25);
        jl3.setForeground(Color.BLUE);
        jl4 = new JLabel("Email");
        jl4.setBounds(100, 250, 100, 25);
        jl4.setForeground(Color.BLUE);
        jl5 = new JLabel("Password");
        jl5.setBounds(100, 300, 100, 25);
        jl5.setForeground(Color.BLUE);
        jl6 = new JLabel("Confirm Password");
        jl6.setBounds(100, 350, 150, 25);
        jl6.setForeground(Color.BLUE);

        // Creating the signup and login buttons
        jb = new JButton("SignUp");
        // Assuming jb is your JButton
        jb.setBounds(245, 600, 100, 25);
        jb.setForeground(Color.BLUE);
        jb.addActionListener(e -> {
            String randomId = generateRandomId();
            String fullName = jt2.getText();
            String phoneNumber = jt3.getText();
            String age = jt4.getText();
            String email = jt5.getText();
            String password = jt6.getText();
            Linker.storeVoterInfo(fullName, phoneNumber, age, email, password, randomId);

            JOptionPane.showMessageDialog(jf, "SignUp Successful!");
            jf.dispose();
            new Main();
        });

        // Adding components to the frame
        jf.add(jt);
        jf.add(jt2);
        jf.add(jt3);
        jf.add(jl);
        jf.add(jl2);
        jf.add(jb);
        jf.add(jt4);
        jf.add(jt5);
        jf.add(jt6);
        jf.add(jt7);
        jf.add(jl3);
        jf.add(jl4);
        jf.add(jl5);
        jf.add(jl6);
        jf.add(ja);

        // Finalizing input
        jf.getContentPane().setBackground(Color.WHITE);
        jf.setSize(600, 500);
        jf.setLayout(null);
        jf.setVisible(true);
    }
    private String generateRandomId() {
        Random random = new Random();
        StringBuilder sb = new StringBuilder();

        // Add the fixed prefix
        sb.append("ETH");

        // Add random alphanumeric characters
        for (int i = sb.length(); i < 10; i++) {
            boolean isDigit = random.nextBoolean(); // Decide whether to add a digit or a letter
            if (isDigit) {
                // Add a random digit (0-9)
                sb.append(random.nextInt(10));
            } else {
                // Add a random letter (upper or lower case)
                char randomChar = (random.nextBoolean()) ?
                        (char) (random.nextInt(26) + 'A') : (char) (random.nextInt(26) + 'a');
                sb.append(randomChar);
            }
        }

        return sb.toString();
    }
    public static void main (String args []){
        new SignUpV();
    }
}
