package gui;

import database.Candidate;
import database.Linker;
import database.Voter;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import static database.Linker.*;

public class VoterCanPro {
    JFrame jf;
    JTextField jt, yu;
    JLabel jl, jl2, jl3, jl4, jl5;
    ImageIcon ii;
    JButton jb;

    public VoterCanPro(Candidate user) {
        jf = new JFrame("Candidate's Profile in Voter's Page");

        // Creating text field
        jt = new JTextField("Hi There");
        jt.setBounds(0, 0, 600, 50);
        jt.setBackground(Color.BLUE);
        jt.setForeground(Color.WHITE);

        // Setting the font size on the text field
        Font font = new Font("TIMES NEW ROMAN", Font.BOLD, 18);
        jt.setFont(font);
        jt.setHorizontalAlignment(JTextField.CENTER);

        // Creating labels
        jl = new JLabel("Full Name: " + user.getFullName());
        jl.setBounds(100, 350, 200, 25);
        jl.setBackground(Color.WHITE);
        jl.setForeground(Color.BLUE);

        jl2 = new JLabel("Position: " + user.getPosition());
        jl2.setBounds(100, 385, 200, 25);
        jl2.setBackground(Color.WHITE);
        jl2.setForeground(Color.BLUE);

        ii = (Resize(user.getImagePath(), 200, 200));
        jl3 = new JLabel(ii);
        jl3.setBounds(100, 50, 350, 300);

        jl4 = new JLabel("Votes");
        jl4.setBounds(400, 25, 50, 25);

        jl5 = new JLabel("ID: " + user.getRandomId());
        jl5.setBounds(100, 410, 200, 25);

        // Setting font for the labels
        Font x = new Font("TIMES NEW ROMAN", Font.PLAIN, 16);
        jl.setFont(x);
        jl2.setFont(x);
        jl3.setFont(x);
        jl4.setFont(x);
        jl5.setFont(x);

        // Creating the vote viewing label
        yu = new JTextField("0");
        yu.setBounds(450, 55, 100, 35);
        yu.setEditable(false);

        int initialVotes = Linker.getCurrentVotesForCandidate(user.getRandomId(), user.getPosition());
        yu.setText(String.valueOf(initialVotes));

        // Creating the vote button
        jb = new JButton("Vote");
        jb.setBounds(450, 250, 100, 25);

        jb.setEnabled(!hasUserVotedForPosition(Linker.getLoggedInUser().getRandomId(), user.getPosition()));
        System.out.println(user.getPosition());

        jb.addActionListener(e -> {
            String y = yu.getText();
            int o = Integer.parseInt(y);
            o = o + 1;
            String l = Integer.toString(o);
            yu.setText(l);
            jb.setEnabled(false);
            updateVoteStatus(Linker.getLoggedInUser().getRandomId(), true, user.getPosition());
            System.out.println(getLoggedInUser().getRandomId());
            Linker.storeVote(getLoggedInUser().getRandomId(), user.getRandomId(), yu, user.getPosition());
        });

        // Adding components to the frame
        jf.add(jl);
        jf.add(jl2);
        jf.add(jt);
        jf.add(jl3);
        jf.add(jl4);
        jf.add(jl5);
        jf.add(yu);
        jf.add(jb);

        jf.setSize(600, 600);
        jf.setLayout(null);
        jf.setVisible(true);
    }

    public ImageIcon Resize(String imagePath, int width, int height) {
        try {
            // Load the original image
            BufferedImage originalImage = ImageIO.read(new File(imagePath));

            // Resize the image while maintaining its aspect ratio
            Image resizedImage = originalImage.getScaledInstance(width, height, Image.SCALE_SMOOTH);

            // Create a button with the resized image
            return new ImageIcon(resizedImage);

        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }
    public static void main (String [] args) {
    }
}