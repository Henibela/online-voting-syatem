package gui;

import database.Candidate;
import database.Linker;
import java.util.Random;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;


public class SignUpC {
    JFrame jf;
    JTextArea gh;
    JTextField jt, jt2, jt3, jt4, jt5, jt6, jt7;
    JLabel jl, jl2, jl3, jl4, jl5, jl6, ja, jl7, imageLabel;
    JButton jb, jb2;
    JComboBox kj;
    private String imagePath;
    public SignUpC() {

        super();
        jf = new JFrame("SignUp Page");

        // Creating text field
        jt = new JTextField("Welcome to Cbits!!!");
        jt.setBounds(0, 0, 600, 50);
        jt.setBackground(Color.WHITE);
        jt.setForeground(Color.BLUE);
        jt.setEditable(false);

        // Setting the font size of the text field
        Font font = new Font("TIMES NEW ROMAN", Font.BOLD, 20);
        jt.setFont(font);
        jt.setHorizontalAlignment(JTextField.CENTER);

        // Creating the opening text area
        ja = new JLabel("Please enter your credentials below");
        ja.setBounds(50, 65, 300, 25);

        // Setting the font of the text area
        Font xy = new Font("TIMES NEW ROMAN", Font.BOLD, 16);
        ja.setFont(xy);

        // Initializing the imageLabel
        imageLabel = new JLabel();
        imageLabel.setBounds(250, 450, 100, 100);
        jf.add(imageLabel);

        String [] position = {"President", "Prime Minister", "Janitor"};
        kj = new JComboBox<>(position);
        kj.setBounds(350, 400, 150, 25);
        kj.setForeground(Color.BLUE);

        // Creating the name and password text fields
        jt2 = new JTextField("Enter Full Name");
        jt2.setBounds(350, 100, 150, 25);
        jt2.setForeground(Color.GRAY);
        jt3 = new JTextField("Enter Phone Number");
        jt3.setBounds(350, 150, 150, 25);
        jt3.setForeground(Color.GRAY);
        jt4 = new JTextField("Enter Age");
        jt4.setBounds(350, 200, 150, 25);
        jt4.setForeground(Color.GRAY);
        jt5 = new JTextField("Enter Email");
        jt5.setBounds(350, 250, 150, 25);
        jt5.setForeground(Color.GRAY);
        jt6 = new JTextField("Enter Password");
        jt6.setBounds(350, 300, 150, 25);
        jt6.setForeground(Color.GRAY);
        jt7 = new JTextField("Confirm Password");
        jt7.setBounds(350, 350, 150, 25);
        jt7.setForeground(Color.GRAY);

        // Creating the name and password labels
        jl = new JLabel("Full Name");
        jl.setBounds(100, 100, 100, 25);
        jl.setForeground(Color.BLUE);
        jl2 = new JLabel("Phone Number");
        jl2.setBounds(100, 150, 100, 25);
        jl2.setForeground(Color.BLUE);
        jl3 = new JLabel("Age");
        jl3.setBounds(100, 200, 100, 25);
        jl3.setForeground(Color.BLUE);
        jl4 = new JLabel("Email");
        jl4.setBounds(100, 250, 100, 25);
        jl4.setForeground(Color.BLUE);
        jl5 = new JLabel("Password");
        jl5.setBounds(100, 300, 100, 25);
        jl5.setForeground(Color.BLUE);
        jl6 = new JLabel("Confirm Password");
        jl6.setBounds(100, 350, 150, 25);
        jl6.setForeground(Color.BLUE);
        jl7 = new JLabel("Position");
        jl7.setBounds(100, 400, 150, 25);
        jl7.setForeground(Color.BLUE);

        // Creating the signup and login buttons
        jb = new JButton();
        // Assuming jb is your JButton
        jb.setIcon(Resize("C:\\Users\\Nas\\IdeaProjects\\SpicyS\\src\\Images\\signup.png", 100, 25));
        jb.setBounds(245, 600, 100, 25);
        jb.setForeground(Color.BLUE);
        jb.addActionListener(e -> {
            String randomId = generateRandomId();
            String fullName = jt2.getText();
            String phoneNumber = jt3.getText();
            String age = jt4.getText();
            String email = jt5.getText();
            String password = jt6.getText();
            String jh = (String) kj.getSelectedItem();
            Linker.storeCandidateInfo(fullName, phoneNumber, age, email, password, jh, imagePath, randomId);

            JOptionPane.showMessageDialog(jf, "SignUp Successful!");
            jf.dispose();
            new Main();
        });

        // Create the button for uploading a photo
        jb2 = new JButton("Photo");
        jb2.setBounds(50, 500, 100, 25);

        jb2.addActionListener(e -> {
            JFileChooser fileChooser = new JFileChooser();
            int result = fileChooser.showOpenDialog(null);

            if (result == JFileChooser.APPROVE_OPTION) {
                File selectedFile = fileChooser.getSelectedFile();
                imagePath = selectedFile.getAbsolutePath();

                // Set the image on the label
                setLabelImage(imagePath);
            }
        });

        // Adding components to the frame
        jf.add(jt);
        jf.add(jt2);
        jf.add(jt3);
        jf.add(jl);
        jf.add(jl2);
        jf.add(jb);
        jf.add(jt4);
        jf.add(jt5);
        jf.add(jt6);
        jf.add(jt7);
        jf.add(jl3);
        jf.add(jl4);
        jf.add(jl5);
        jf.add(jl6);
        jf.add(ja);
        jf.add(kj);
        jf.add(jl7);
        jf.add(jb2);

        // Finalizing input
        jf.getContentPane().setBackground(Color.WHITE);
        jf.setSize(600, 900);
        jf.setLayout(null);
        jf.setVisible(true);

    }
    private void setLabelImage(String imagePath) {
        try {
            // Read the image file
            BufferedImage img = ImageIO.read(new File(imagePath));

            // Scale the image to fit the label dimensions
            Image scaledImg = img.getScaledInstance(imageLabel.getWidth(), imageLabel.getHeight(), Image.SCALE_SMOOTH);

            // Set the scaled image on the label
            imageLabel.setIcon(new ImageIcon(scaledImg));
        } catch (IOException ex) {
            ex.printStackTrace();
            // Handle the exception (e.g., show an error message)
        }
    }
    private String generateRandomId() {
        Random random = new Random();
        StringBuilder sb = new StringBuilder();

        // Add the fixed prefix
        sb.append("ETH");

        // Add random alphanumeric characters
        for (int i = sb.length(); i < 10; i++) {
            boolean isDigit = random.nextBoolean(); // Decide whether to add a digit or a letter
            if (isDigit) {
                // Add a random digit (0-9)
                sb.append(random.nextInt(10));
            } else {
                // Add a random letter (upper or lower case)
                char randomChar = (random.nextBoolean()) ?
                        (char) (random.nextInt(26) + 'A') : (char) (random.nextInt(26) + 'a');
                sb.append(randomChar);
            }
        }

        return sb.toString();
    }

    public ImageIcon Resize(String imagePath, int width, int height) {
        try {
            // Load the original image
            BufferedImage originalImage = ImageIO.read(new File(imagePath));

            // Resize the image while maintaining its aspect ratio
            Image resizedImage = originalImage.getScaledInstance(width, height, Image.SCALE_SMOOTH);

            // Create a button with the resized image
            return new ImageIcon(resizedImage);

        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }
    public static void main (String [] args) {
        new SignUpC();
    }
}
